﻿window.offlineDb = {
    dbName: "SMSPWA_OfflineDB",
    dbVersion: 2,
    storeName: "MasterRecords",
    hardDeleteTableCode: 35,

    normalizeRecord: function (raw) {
        if (!raw) return null;

        const rawId = raw.id ?? raw.Id;
        const id = rawId !== null && rawId !== undefined && String(rawId).trim() !== ""
            ? String(rawId)
            : null;

        const tableCode = Number(raw.tableCode ?? raw.TableCode ?? 0);
        const parentId = raw.parentId ?? raw.ParentId ?? null;

        const rawBranch = raw.branchId ?? raw.BranchId ?? null;
        const branchId = rawBranch !== null && rawBranch !== "" ? Number(rawBranch) : null;

        const rawSubBranch = raw.subBranchId ?? raw.SubBranchId ?? 0;
        const subBranchId = rawSubBranch !== null && rawSubBranch !== "" ? Number(rawSubBranch) : 0;

        const rawSyncOnline = raw.syncCodOnline ?? raw.SyncCodOnline ?? raw.syncCode ?? raw.SyncCode ?? 0;
        const syncCodOnline = Number(rawSyncOnline);

        const rawSyncMain = raw.syncCodeForMainServer ?? raw.SyncCodeForMainServer ?? 0;
        const syncCodeForMainServer = Number(rawSyncMain);

        const rawSerial = raw.mainServerSerialNo ?? raw.MainServerSerialNo ?? null;
        const mainServerSerialNo = rawSerial !== null && rawSerial !== "" ? Number(rawSerial) : null;

        const activeVal = raw.isActive ?? raw.IsActive ?? true;
        const isActive = activeVal === true || activeVal === 1 || String(activeVal).toLowerCase() === "true";

        return {
            ...raw,
            id: id,
            tableCode: tableCode,
            parentId: parentId ? String(parentId) : null,
            branchId: branchId,
            subBranchId: subBranchId,

            a: raw.a ?? raw.A ?? null,
            b: raw.b ?? raw.B ?? null,
            c: raw.c ?? raw.C ?? null,
            d: raw.d ?? raw.D ?? null,
            e: raw.e ?? raw.E ?? null,
            f: raw.f ?? raw.F ?? null,
            g: raw.g ?? raw.G ?? null,
            h: raw.h ?? raw.H ?? null,
            i: raw.i ?? raw.I ?? null,
            j: raw.j ?? raw.J ?? null,
            k: raw.k ?? raw.K ?? null,
            l: raw.l ?? raw.L ?? null,
            m: raw.m ?? raw.M ?? null,
            n: raw.n ?? raw.N ?? null,
            o: raw.o ?? raw.O ?? null,
            p: raw.p ?? raw.P ?? null,
            q: raw.q ?? raw.Q ?? null,
            r: raw.r ?? raw.R ?? null,

            isActive: isActive,
            syncCodOnline: syncCodOnline,
            syncCodeForMainServer: syncCodeForMainServer,
            mainServerSerialNo: mainServerSerialNo
        };
    },

    formatBranchCode: function (branchId, subBranchId) {
        const mainNum = branchId && Number(branchId) > 0 ? Number(branchId) : 1;
        const mainCode = "SMS-" + String(mainNum).padStart(2, "0");
        const subNum = subBranchId ? Number(subBranchId) : 0;

        if (subNum > 0) {
            return mainCode + "-" + String(subNum).padStart(2, "0");
        }
        return mainCode;
    },

    open: function () {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                let store;

                if (!db.objectStoreNames.contains(this.storeName)) {
                    store = db.createObjectStore(this.storeName, { keyPath: "id" });
                } else {
                    store = event.target.transaction.objectStore(this.storeName);
                }

                const ensureIndex = (name, keyPath, options = { unique: false }) => {
                    if (!store.indexNames.contains(name)) {
                        store.createIndex(name, keyPath, options);
                    }
                };

                ensureIndex("tableCode", "tableCode", { unique: false });
                ensureIndex("table_a", ["tableCode", "a"], { unique: false });
                ensureIndex("table_b", ["tableCode", "b"], { unique: false });
                ensureIndex("table_c", ["tableCode", "c"], { unique: false });
                ensureIndex("syncCode", "syncCode", { unique: false });
                ensureIndex("syncCodOnline", "syncCodOnline", { unique: false });
                ensureIndex("syncCodeForMainServer", "syncCodeForMainServer", { unique: false });
                ensureIndex("mainServerSerialNo", "mainServerSerialNo", { unique: false });
                ensureIndex("branchId", "branchId", { unique: false });
                ensureIndex("subBranchId", "subBranchId", { unique: false });
            };

            request.onsuccess = (event) => resolve(event.target.result);
            request.onerror = (event) => reject(event.target.error);
        });
    },

    saveRecord: async function (record) {
        const db = await this.open();
        const normalized = this.normalizeRecord(record);
        if (!normalized || !normalized.id) {
            throw new Error("Record must have a valid id.");
        }

        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            store.put(normalized);

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error || new Error("Transaction aborted"));
        });
    },

    saveBatch: async function (records) {
        if (!Array.isArray(records) || records.length === 0) return 0;

        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            let count = 0;

            for (const rec of records) {
                const item = this.normalizeRecord(rec);
                if (item && item.id) {
                    store.put(item);
                    count++;
                }
            }

            tx.oncomplete = () => resolve(count);
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error || new Error("Batch transaction aborted"));
        });
    },

    deleteRecordsByIds: async function (ids) {
        if (!Array.isArray(ids) || ids.length === 0) return 0;

        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            let deleted = 0;

            for (const rawId of ids) {
                if (!rawId) continue;
                const key = String(rawId).trim();
                if (!key) continue;
                store.delete(key);
                deleted++;
            }

            tx.oncomplete = () => resolve(deleted);
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error || new Error("Delete transaction aborted"));
        });
    },

    applyPullBatch: async function (records) {
        if (!Array.isArray(records) || records.length === 0) return 0;

        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            let count = 0;

            for (const rec of records) {
                const item = this.normalizeRecord(rec);
                if (!item || !item.id) continue;

                if (Number(item.tableCode) === this.hardDeleteTableCode) {
                    const targetId = item.parentId || item.a;
                    if (targetId && String(targetId).trim() !== "") {
                        store.delete(String(targetId).trim());
                    }
                    // Tombstone row ko bhi put karein taake mainServerSerialNo sync sequence intact rahe
                    store.put(item);
                    count++;
                } else {
                    store.put(item);
                    count++;
                }
            }

            tx.oncomplete = () => resolve(count);
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error || new Error("Pull batch transaction aborted"));
        });
    },

    getById: async function (id) {
        if (!id) return null;
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const req = store.get(String(id));
            req.onsuccess = () => resolve(req.result || null);
            req.onerror = () => reject(req.error);
        });
    },

    getByTableAndA: async function (tableCode, valA) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const index = store.index("table_a");
            const req = index.getAll([Number(tableCode), valA]);
            req.onsuccess = () => {
                const results = req.result || [];
                const active = results.find(r =>
                    Number(r.tableCode) !== this.hardDeleteTableCode &&
                    (r.isActive === true || r.isActive === 1)
                );
                resolve(active || null);
            };
            req.onerror = () => reject(req.error);
        });
    },

    getAllByTableCode: async function (tableCode, includeInactive = false) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const index = store.index("tableCode");
            const req = index.getAll(Number(tableCode));
            req.onsuccess = () => {
                let results = req.result || [];
                if (Number(tableCode) !== this.hardDeleteTableCode) {
                    results = results.filter(r => Number(r.tableCode) !== this.hardDeleteTableCode);
                }
                if (!includeInactive) {
                    results = results.filter(r => r.isActive === true || r.isActive === 1);
                }
                results.sort((a, b) => {
                    const sa = a.mainServerSerialNo ?? Number.MAX_SAFE_INTEGER;
                    const sb = b.mainServerSerialNo ?? Number.MAX_SAFE_INTEGER;
                    if (sa !== sb) return sa - sb;
                    return String(a.createDate || "").localeCompare(String(b.createDate || ""));
                });
                resolve(results);
            };
            req.onerror = () => reject(req.error);
        });
    },

    getUnsyncedRecords: async function () {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const req = store.getAll();
            req.onsuccess = () => {
                const all = req.result || [];
                resolve(all.filter(r => {
                    const status = r.syncCodOnline !== undefined && r.syncCodOnline !== null
                        ? Number(r.syncCodOnline)
                        : Number(r.syncCode ?? 0);
                    return status !== 1;
                }));
            };
            req.onerror = () => reject(req.error);
        });
    },

    markSyncedOnline: async function (ids, serialMap = null) {
        if (!Array.isArray(ids) || ids.length === 0) return 0;

        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            let updated = 0;

            for (const rawId of ids) {
                const key = String(rawId);
                const getReq = store.get(key);
                getReq.onsuccess = () => {
                    const row = getReq.result;
                    if (row) {
                        row.syncCodOnline = 1;
                        row.syncCode = 1;
                        if (serialMap && serialMap[key] !== undefined && serialMap[key] !== null) {
                            row.mainServerSerialNo = Number(serialMap[key]);
                            row.syncCodeForMainServer = 1;
                        }
                        store.put(row);
                        updated++;
                    }
                };
            }

            tx.oncomplete = () => resolve(updated);
            tx.onerror = () => reject(tx.error);
        });
    },

    updateMainServerSerialById: async function (id, mainServerSerialNo) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            const key = String(id);
            const getReq = store.get(key);

            getReq.onsuccess = () => {
                const row = getReq.result;
                if (!row) {
                    resolve(false);
                    return;
                }
                row.mainServerSerialNo = mainServerSerialNo !== null && mainServerSerialNo !== undefined
                    ? Number(mainServerSerialNo)
                    : null;
                row.syncCodeForMainServer = row.mainServerSerialNo !== null ? 1 : 0;
                row.syncCodOnline = 1;
                row.syncCode = 1;
                store.put(row);
                resolve(true);
            };
            getReq.onerror = () => reject(getReq.error);
        });
    },

    getRecordsBatch: async function (tableCode = null, afterSerial = 0, batchSize = 200) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const req = store.getAll();

            req.onsuccess = () => {
                let rows = (req.result || []).filter(r => r.isActive === true || r.isActive === 1);
                if (tableCode !== null && tableCode !== undefined) {
                    rows = rows.filter(r => Number(r.tableCode) === Number(tableCode));
                }
                if (Number(afterSerial) > 0) {
                    rows = rows.filter(r => Number(r.mainServerSerialNo || 0) > Number(afterSerial));
                }
                rows.sort((a, b) => Number(a.mainServerSerialNo || 0) - Number(b.mainServerSerialNo || 0));
                resolve(rows.slice(0, Number(batchSize) || 200));
            };
            req.onerror = () => reject(req.error);
        });
    }
};

window.isDeviceOnline = function () {
    return navigator.onLine;
};