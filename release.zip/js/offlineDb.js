﻿window.offlineDb = {
    dbName: "SMSPWA_OfflineDB",
    dbVersion: 1,
    storeName: "MasterRecords",

    open: function () {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) {
                    const store = db.createObjectStore(this.storeName, { keyPath: "id" });
                    store.createIndex("tableCode", "tableCode", { unique: false });
                    store.createIndex("table_a", ["tableCode", "a"], { unique: false });
                    store.createIndex("table_b", ["tableCode", "b"], { unique: false });
                    store.createIndex("table_c", ["tableCode", "c"], { unique: false });
                    store.createIndex("syncCode", "syncCode", { unique: false });
                }
            };

            request.onsuccess = (event) => resolve(event.target.result);
            request.onerror = (event) => reject(event.target.error);
        });
    },

    saveRecord: async function (record) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            const store = tx.objectStore(this.storeName);
            const req = store.put(record);
            req.onsuccess = () => resolve(true);
            req.onerror = () => reject(req.error);
        });
    },

    getByTableAndA: async function (tableCode, valA) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const index = store.index("table_a");
            const req = index.getAll([tableCode, valA]);
            req.onsuccess = () => {
                const results = req.result || [];
                const active = results.find(r => r.isActive === true);
                resolve(active || null);
            };
            req.onerror = () => reject(req.error);
        });
    },

    getAllByTableCode: async function (tableCode) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const index = store.index("tableCode");
            const req = index.getAll(tableCode);
            req.onsuccess = () => {
                const results = req.result || [];
                resolve(results.filter(r => r.isActive === true));
            };
            req.onerror = () => reject(req.error);
        });
    },

    getUnsyncedRecords: async function () {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const store = tx.objectStore(this.storeName);
            const req = store.getAll();
            req.onsuccess = () => {
                const all = req.result || [];
                resolve(all.filter(r => r.syncCode !== 1));
            };
            req.onerror = () => reject(req.error);
        });
    }
};
window.isDeviceOnline = function () {
    return navigator.onLine;
};