﻿window.getDeviceAndGeoInfo = async function () {
    const nav = navigator || {};
    const scr = screen || {};

    let deviceId = "";
    try {
        deviceId = localStorage.getItem("smspwa_device_id") || "";
        if (!deviceId) {
            deviceId = (crypto && crypto.randomUUID)
                ? crypto.randomUUID()
                : ("DEV-" + Date.now() + "-" + Math.random().toString(36).substring(2, 9));
            localStorage.setItem("smspwa_device_id", deviceId);
        }
    } catch {
        deviceId = "DEV-" + Date.now() + "-" + Math.random().toString(36).substring(2, 9);
    }

    const ua = nav.userAgent || "";
    const isMobile = /Android|iPhone|iPad|iPod|Mobile|BlackBerry|IEMobile|Opera Mini/i.test(ua)
        || (nav.maxTouchPoints && nav.maxTouchPoints > 1 && /Mac|Linux|Android/i.test(ua));

    const deviceType = isMobile ? "Mobile" : "Desktop / Laptop";
    const cores = nav.hardwareConcurrency || "N/A";
    const memory = nav.deviceMemory ? (nav.deviceMemory + "GB") : "N/A";
    const dpr = window.devicePixelRatio || 1;
    const screenRes = `${scr.width || 0}x${scr.height || 0}@${dpr}x`;
    const platform = (nav.userAgentData && nav.userAgentData.platform) || nav.platform || "Unknown";
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
    const language = nav.language || "";

    const rawSpec = `${deviceId}|${deviceType}|${platform}|${cores}|${memory}|${screenRes}|${timeZone}`;
    let hashHex = "";
    try {
        if (crypto && crypto.subtle && window.isSecureContext) {
            const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(rawSpec));
            hashHex = Array.from(new Uint8Array(buf))
                .map(b => b.toString(16).padStart(2, "0"))
                .join("")
                .substring(0, 16)
                .toUpperCase();
        }
    } catch { }

    const hardwareId = hashHex
        ? `${isMobile ? "MOB" : "PC"}-${hashHex}`
        : deviceId;

    const osAndBrowser = `${platform} | Cores:${cores} | RAM:${memory} | ${screenRes} | ${timeZone} | ${language}`;

    let ipAddress = "Offline / N/A";
    let country = "Unknown";
    let location = timeZone || "Unknown";

    if (navigator.onLine) {
        try {
            const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
            const timerId = controller ? setTimeout(() => controller.abort(), 2000) : null;

            const resp = await fetch("https://ipapi.co/json/", {
                cache: "no-store",
                signal: controller ? controller.signal : undefined
            });

            if (timerId) clearTimeout(timerId);

            if (resp.ok) {
                const geo = await resp.json();
                ipAddress = geo.ip || ipAddress;
                country = geo.country_name || country;
                const parts = [geo.city, geo.region].filter(Boolean);
                if (parts.length > 0) location = parts.join(", ");
            }
        } catch { }

        if (nav.geolocation && window.isSecureContext) {
            try {
                const pos = await Promise.race([
                    new Promise((resolve, reject) => {
                        nav.geolocation.getCurrentPosition(resolve, reject, {
                            enableHighAccuracy: false,
                            timeout: 2000,
                            maximumAge: 600000
                        });
                    }),
                    new Promise((_, reject) => setTimeout(() => reject(new Error("GeoTimeout")), 2200))
                ]);

                if (pos && pos.coords) {
                    const lat = pos.coords.latitude.toFixed(4);
                    const lon = pos.coords.longitude.toFixed(4);
                    location = `${location} (${lat}, ${lon})`;
                }
            } catch { }
        }
    }

    return {
        deviceId: deviceId,
        deviceType: deviceType,
        hardwareId: hardwareId,
        osAndBrowser: osAndBrowser,
        ipAddress: ipAddress,
        country: country,
        location: location,
        summary: `Id=${deviceId}; Type=${deviceType}; HW=${hardwareId}; IP=${ipAddress}; Country=${country}; Loc=${location}`
    };
};