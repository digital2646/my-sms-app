self.assetsManifest = {
  "version": "S9EWgi7l",
  "assets": [
    {
      "hash": "sha256-S6TNt3FHVUUykVlIhhMIsOPc56pA40lvTKzeueFvZ2o=",
      "url": "SMSPWA.styles.css"
    },
    {
      "hash": "sha256-N39N8zYgqDE0bWdoPrtPeW24V6ByqCXZlEnf4Urue7E=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.b7njz8u6cx.wasm"
    },
    {
      "hash": "sha256-bAND2B3KdaaI77zRlymt238IkdU56p4MTadqNbkroWI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.s6imvm6sn2.wasm"
    },
    {
      "hash": "sha256-AYyvKAqeRROcjj571CUe+xB+t122UUFx5+3ogrMJr98=",
      "url": "_framework/Microsoft.AspNetCore.Components.v84a0shh95.wasm"
    },
    {
      "hash": "sha256-YMQXBk4jrVc9OaTp+/KtO0wrrkF0KurH384yJ5BMY6o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.wslsrredsq.wasm"
    },
    {
      "hash": "sha256-hR3hJyllFhcAJODYJ4O/15D7zPKt4rm31ndgrYDdAXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dmmcgk01r0.wasm"
    },
    {
      "hash": "sha256-C7GPXPXoVldDMNqp7glnbWRY3LqQV22sIZt68+o3YTM=",
      "url": "_framework/Microsoft.Extensions.Configuration.rgjmp347zf.wasm"
    },
    {
      "hash": "sha256-g9IWKrzfFdPHol+mXiAkFtrd+e2MIJsJ24KlqW7ToFQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.5uca2vr0u0.wasm"
    },
    {
      "hash": "sha256-65t55x0o9XbVcieUSVTIzsy8s+wm8VqdFZu/UCoGvME=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.93m90bc7u9.wasm"
    },
    {
      "hash": "sha256-lRjcnCHTmTMrXGDBaGeTpsqaIN8HKNvcCHj+b6hrj5Q=",
      "url": "_framework/Microsoft.Extensions.Logging.5w9ia7xlgq.wasm"
    },
    {
      "hash": "sha256-CWDOH6i7pG8OQBcQTgvYzQBND7Hos3abs0KJifQuAqo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.hyr6hrp8cs.wasm"
    },
    {
      "hash": "sha256-TqcuRfsHDo1I9fA6NleVgI/6BwkPHpdQbhJJ7PXpJ7Q=",
      "url": "_framework/Microsoft.Extensions.Options.espvvlqak1.wasm"
    },
    {
      "hash": "sha256-KDipvixud3wtosnTZ5tXsIUx4dF6DiSZ4kK8quRG+xo=",
      "url": "_framework/Microsoft.Extensions.Primitives.crxdkm6t9l.wasm"
    },
    {
      "hash": "sha256-kA4OIaWbB6obNbKQ/H9VxCYrWP9jiy3WDB3jS21K2o8=",
      "url": "_framework/Microsoft.JSInterop.0s2ioyhd7k.wasm"
    },
    {
      "hash": "sha256-A1+r9KkQJ1Kkm98VWekGd8z84GzOPdY9wh/SHfyyQg4=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ql0ra5mpq.wasm"
    },
    {
      "hash": "sha256-sf69LO7/rYliVlNnWdFjJOYE5wrOQk3oZrdCg9eWSU8=",
      "url": "_framework/SMSPWA.hgemwjopmn.wasm"
    },
    {
      "hash": "sha256-32Y68zFKijTRmK1+RkkyTk7/ywZstUN4HzhVGRxzuwQ=",
      "url": "_framework/System.Collections.Concurrent.5j78xctqnt.wasm"
    },
    {
      "hash": "sha256-jMOcvkApUOP80v8WixTvYK6mVgGTYFzDR7YsBs3PlCo=",
      "url": "_framework/System.Collections.Immutable.cunnsehbnj.wasm"
    },
    {
      "hash": "sha256-b4m6p/210iAqqwcJTGiRLjai4LdyIEDtoa9fPN5GL/s=",
      "url": "_framework/System.Collections.zb0fu39yf9.wasm"
    },
    {
      "hash": "sha256-9Fm6GAyFmib1JLplgnBmpwua/+VI5d5CwLicsduEa1U=",
      "url": "_framework/System.ComponentModel.g3pwvcjcrg.wasm"
    },
    {
      "hash": "sha256-Jl0Hp0x07/+Gg5ajIgND7xwnEFnIh7j9I2cgLE7PEgc=",
      "url": "_framework/System.Console.mha7yojebf.wasm"
    },
    {
      "hash": "sha256-dsAcz2wzVucNlYwuaeGC+x/HaWF9CXjSEm4X/cICX3E=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2h9ux9nxld.wasm"
    },
    {
      "hash": "sha256-P3efMSOfVCOb4KRJxC8w5mdhwshNltAbNhD4m3E4ekU=",
      "url": "_framework/System.IO.Pipelines.d9jdqrkwk1.wasm"
    },
    {
      "hash": "sha256-QxVFo+Gbw96sjziQljMjmPBv9aJKXuK4Rsp1IBh2QUQ=",
      "url": "_framework/System.Linq.hfpgqjocid.wasm"
    },
    {
      "hash": "sha256-zj7wFI7BuKsFcX4XlQeZ53Ora2C3IcoigWyGBEEisF8=",
      "url": "_framework/System.Memory.qt65tksv1c.wasm"
    },
    {
      "hash": "sha256-BywqH95LKOIke4n1wczSbxv9dYikKq28RzF2Iad0pLk=",
      "url": "_framework/System.Net.Http.3lpmx4z2i9.wasm"
    },
    {
      "hash": "sha256-dQLAzillxnab2rC7XvgSRpEvnGZuTARyRcvk/9DcOpM=",
      "url": "_framework/System.Net.Http.Json.b8a3nkui3h.wasm"
    },
    {
      "hash": "sha256-s9rRUomPsrQ7CPYjy7VfHuyk+5Zcz4sL/Uy1Bx9uYZg=",
      "url": "_framework/System.Net.Primitives.be7t0gdwz9.wasm"
    },
    {
      "hash": "sha256-5ymOcwdUq6l7evwMr3rwKCvOYWyg7CfY10BWFsQAUKw=",
      "url": "_framework/System.Private.CoreLib.3p29k4517v.wasm"
    },
    {
      "hash": "sha256-iFjyLHBSazigN+29kGWA5xuPwT9upcuLOjZ+jCK8M0Q=",
      "url": "_framework/System.Private.Uri.0izfylfuug.wasm"
    },
    {
      "hash": "sha256-bwCKI2DX6eI2ToOrFi6+lX3EctvmvOAgtsuj/79XJ34=",
      "url": "_framework/System.Runtime.722k1y1hf6.wasm"
    },
    {
      "hash": "sha256-hj26LVfbFpoVPyXTjAXdVk41FKNiFwr2eGNynxIaSNQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.qba5uzr262.wasm"
    },
    {
      "hash": "sha256-sJvdG9iEW9S28wAoeZPsjuZ+Dn5lEaiWXp+3JNDZgcw=",
      "url": "_framework/System.Security.Cryptography.knctfgxfsk.wasm"
    },
    {
      "hash": "sha256-HnBJ4s48Max4DNoVYJpCw2L0Dmt48WCcJg9NqVTAcGQ=",
      "url": "_framework/System.Text.Encodings.Web.mmvw4p499f.wasm"
    },
    {
      "hash": "sha256-soeGUriJsuHBSsX5cdINmFJRd5nH6zNaREHBE1I6mvs=",
      "url": "_framework/System.Text.Json.ybimi8g4pd.wasm"
    },
    {
      "hash": "sha256-GYxZulUJOx+OwleiQ4wly2mse6dyLsBZOwMQcAr7zcM=",
      "url": "_framework/System.Text.RegularExpressions.fid2jwd6ww.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-JCBK2hg5bJ/qmYexx4qsb0YB5AjRNq1TahUbfqBvRtQ=",
      "url": "_framework/dotnet.native.4ey3fwudxk.js"
    },
    {
      "hash": "sha256-JXlXvoGdKOewuc0+K4+XgAmrlNHPqyC1QV5e0gsKc4Q=",
      "url": "_framework/dotnet.native.rouybf73ed.wasm"
    },
    {
      "hash": "sha256-uK0X7tsyl+sd8WU6c1BJJ90CLqF5DFwPluMZjPqS368=",
      "url": "_framework/dotnet.osbsj87o8g.js"
    },
    {
      "hash": "sha256-/3dBg9sj1yLD3h0PDMHnNUXWs/2zWwIMEzom1Xz3Q40=",
      "url": "_framework/dotnet.runtime.5nc8i5dl74.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-X9Jvci7B6LCRgwIpqxMFz824rFRaE0sFLZER0Rbkuhg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-wUa3jv/J/59Ub7X+gxMenCVW9Bumqu5xWoAmjOI/eDA=",
      "url": "js/offlineDb.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-rOccmviT/tDD6aAt+idZL+UijJcRktR/hzeKu3LyrUU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-GBPSZCbJ7jt2B3KMT4Ph0ZnbKu7gOENVqpHwbLhpNRM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-2q++/gYCH5kOs4pOTTpAeLQHdBLmKYjCCYoeki4evDE=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-010DfBnfOSjz850qIuePbwz2a5pm55afz9WhRhlQPPs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-Oj8RV2G2qnTUNQMXeBJFblacJlOLSdG1Z5uvQ0Uzb78=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-YHPUhiKUe5tlDx4ZaE3qfRzju/1Prp+ibYzEFTB+kWE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-D+EnRvRuOB65sDHl4GTkpvw8eRvaigODewoN7KR6uis=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-NuJSj11Ox+TMZmKhYei6WngN4OQZrTrqvp/uMBf7Z8E=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-3yMPdt4/YOJyxf0xoGcnghWwYXUwiu5i4yn2fqIK40U=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-cgYRZz9qYmn0XsaiFXMhF487kkqIMR8Vqm7vl1uvaMY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
