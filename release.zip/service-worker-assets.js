self.assetsManifest = {
  "version": "kFe6Bk1h",
  "assets": [
    {
      "hash": "sha256-NGmmDQ5Jl85uxiDs3yppzFADDISfIHYpO2S6MhlWnWs=",
      "url": "404.html"
    },
    {
      "hash": "sha256-a6Cyo5R1/VCxdsXfUkTD8Mc+7ap6K31beI6xT6sq7Eo=",
      "url": "SMSPWA.styles.css"
    },
    {
      "hash": "sha256-Sspg5GhGW3nfw7EwrejVno3oAg55j6Q71B5Roj0MEDU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.az4ike0ji3.wasm"
    },
    {
      "hash": "sha256-mwcvAM8DnneKMrz48qonPQBoPDDFj79AUC3fLWvmEsc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.1tpbh8xnzh.wasm"
    },
    {
      "hash": "sha256-Z+L5nFu9xcHL+l80AXOP7EjL0WiCeX5Sr78MkyTJVLA=",
      "url": "_framework/Microsoft.AspNetCore.Components.tn83f064go.wasm"
    },
    {
      "hash": "sha256-YMQXBk4jrVc9OaTp+/KtO0wrrkF0KurH384yJ5BMY6o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.wslsrredsq.wasm"
    },
    {
      "hash": "sha256-hR3hJyllFhcAJODYJ4O/15D7zPKt4rm31ndgrYDdAXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dmmcgk01r0.wasm"
    },
    {
      "hash": "sha256-C7GPXPXoVldDMNqp7glnbWRY3LqQV22sIZt68+o3YTM=",
      "url": "_framework/Microsoft.Extensions.Configuration.rgjmp347zf.wasm"
    },
    {
      "hash": "sha256-g9IWKrzfFdPHol+mXiAkFtrd+e2MIJsJ24KlqW7ToFQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.5uca2vr0u0.wasm"
    },
    {
      "hash": "sha256-65t55x0o9XbVcieUSVTIzsy8s+wm8VqdFZu/UCoGvME=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.93m90bc7u9.wasm"
    },
    {
      "hash": "sha256-lRjcnCHTmTMrXGDBaGeTpsqaIN8HKNvcCHj+b6hrj5Q=",
      "url": "_framework/Microsoft.Extensions.Logging.5w9ia7xlgq.wasm"
    },
    {
      "hash": "sha256-NSLwO1ByZjJg7zilLOVI+R9FN3kKGhABqtcmSJDKxS8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.xx3hs6cn2q.wasm"
    },
    {
      "hash": "sha256-MNrbxhQ7wkE7eNxga78hv8dEZC6M98ZOTsgOy5A6UJM=",
      "url": "_framework/Microsoft.Extensions.Options.ouqxsmik00.wasm"
    },
    {
      "hash": "sha256-KDipvixud3wtosnTZ5tXsIUx4dF6DiSZ4kK8quRG+xo=",
      "url": "_framework/Microsoft.Extensions.Primitives.crxdkm6t9l.wasm"
    },
    {
      "hash": "sha256-kA4OIaWbB6obNbKQ/H9VxCYrWP9jiy3WDB3jS21K2o8=",
      "url": "_framework/Microsoft.JSInterop.0s2ioyhd7k.wasm"
    },
    {
      "hash": "sha256-A1+r9KkQJ1Kkm98VWekGd8z84GzOPdY9wh/SHfyyQg4=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ql0ra5mpq.wasm"
    },
    {
      "hash": "sha256-hnOvtwEbXO0u9aJ9pfhJieModctWathbtLH6KAHX8H8=",
      "url": "_framework/SMSPWA.2he9a6yqyx.wasm"
    },
    {
      "hash": "sha256-5B2gnM4F6Yw6o8EDzQ8u6YEBzrwZyvpvnfZlJtSOezs=",
      "url": "_framework/System.Collections.Concurrent.orwwwkodlq.wasm"
    },
    {
      "hash": "sha256-dJGL+QpHch0zTtl3QoX8dYB/Saxunn8hfq+BeSar6Fk=",
      "url": "_framework/System.Collections.Immutable.0dm1y2grw7.wasm"
    },
    {
      "hash": "sha256-itXIhZQyztAKhNPNVLpfGL8B/fwCGRD7aOVY6nemeRo=",
      "url": "_framework/System.Collections.aww07ygwe5.wasm"
    },
    {
      "hash": "sha256-9Fm6GAyFmib1JLplgnBmpwua/+VI5d5CwLicsduEa1U=",
      "url": "_framework/System.ComponentModel.g3pwvcjcrg.wasm"
    },
    {
      "hash": "sha256-Jl0Hp0x07/+Gg5ajIgND7xwnEFnIh7j9I2cgLE7PEgc=",
      "url": "_framework/System.Console.mha7yojebf.wasm"
    },
    {
      "hash": "sha256-7pypjNXSXSMil99XbPW3v6Imm3iTZ9rGj1Ooo0T/DEc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.a1ccx1v6s9.wasm"
    },
    {
      "hash": "sha256-P3efMSOfVCOb4KRJxC8w5mdhwshNltAbNhD4m3E4ekU=",
      "url": "_framework/System.IO.Pipelines.d9jdqrkwk1.wasm"
    },
    {
      "hash": "sha256-JskAtvsqPFe18F0E+j97DeNzM5VCkcReV5VcoIjp8WU=",
      "url": "_framework/System.Linq.iexf8ix57y.wasm"
    },
    {
      "hash": "sha256-EQSZCqJmQvZiu/TMC2Yx3OioRxkKaenO/R0CDeJj1vI=",
      "url": "_framework/System.Memory.9281dmm6sl.wasm"
    },
    {
      "hash": "sha256-dQLAzillxnab2rC7XvgSRpEvnGZuTARyRcvk/9DcOpM=",
      "url": "_framework/System.Net.Http.Json.b8a3nkui3h.wasm"
    },
    {
      "hash": "sha256-YJ357F3SbiR3AGKUvC+GQ2cL7jRrSx6omH0MPJau5Yo=",
      "url": "_framework/System.Net.Http.g8bm75qyte.wasm"
    },
    {
      "hash": "sha256-s9rRUomPsrQ7CPYjy7VfHuyk+5Zcz4sL/Uy1Bx9uYZg=",
      "url": "_framework/System.Net.Primitives.be7t0gdwz9.wasm"
    },
    {
      "hash": "sha256-DJyDEXysqEqCiR5CoAgXkGbeziHeuXpL73Rp489AVkM=",
      "url": "_framework/System.Private.CoreLib.seiv1p19jo.wasm"
    },
    {
      "hash": "sha256-scSln705p/JuUjR+tJXYryhoDnXLuy5O1yZCCgtkli0=",
      "url": "_framework/System.Private.Uri.pqb173o4j7.wasm"
    },
    {
      "hash": "sha256-hj26LVfbFpoVPyXTjAXdVk41FKNiFwr2eGNynxIaSNQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.qba5uzr262.wasm"
    },
    {
      "hash": "sha256-Br3lXXIJowgoKL+wkYL7qrQFWbHaIKGR/Weabh6Y43M=",
      "url": "_framework/System.Runtime.eqt61o6e2t.wasm"
    },
    {
      "hash": "sha256-sJvdG9iEW9S28wAoeZPsjuZ+Dn5lEaiWXp+3JNDZgcw=",
      "url": "_framework/System.Security.Cryptography.knctfgxfsk.wasm"
    },
    {
      "hash": "sha256-L/Kydhpdf8pNN1kertWZnYnIsZx8cP2i/vszfww7G+8=",
      "url": "_framework/System.Text.Encodings.Web.rlaiw7pjsx.wasm"
    },
    {
      "hash": "sha256-AfTaevJ0PnJzZJ/OBvrtTwJsxbdJjzDeGPMIlMyvvjM=",
      "url": "_framework/System.Text.Json.dh5hijciae.wasm"
    },
    {
      "hash": "sha256-y7fGXqnkPZhtupbAz/qTKeebx7o+eb2wYOKOzJsQSG8=",
      "url": "_framework/System.Text.RegularExpressions.zefvsnsxux.wasm"
    },
    {
      "hash": "sha256-ppeC+L9BJdmTXunluikS6MYVomWpRWVXX14qIYghm4o=",
      "url": "_framework/System.Threading.ezqz50t0nu.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-Eu5VRQOr7794Qj/xwKM0AzqE5qW2EUyZGUTSh8XhWKk=",
      "url": "_framework/dotnet.636ti6gsoj.js"
    },
    {
      "hash": "sha256-JCBK2hg5bJ/qmYexx4qsb0YB5AjRNq1TahUbfqBvRtQ=",
      "url": "_framework/dotnet.native.4ey3fwudxk.js"
    },
    {
      "hash": "sha256-y4e/hqpjMnjZadpEECKCz5Pj+Fq9dZyD2HTW5qrl5xs=",
      "url": "_framework/dotnet.native.hhscl2ecia.wasm"
    },
    {
      "hash": "sha256-/3dBg9sj1yLD3h0PDMHnNUXWs/2zWwIMEzom1Xz3Q40=",
      "url": "_framework/dotnet.runtime.5nc8i5dl74.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-l/EpFaIIxZexONe35U8SuelKKty86YHHosrqk7mTTEE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-NGmmDQ5Jl85uxiDs3yppzFADDISfIHYpO2S6MhlWnWs=",
      "url": "index.html"
    },
    {
      "hash": "sha256-j00yERjTMFjpBgs5kC1Q/AZiOBkqDxa98NAbzXi6+lA=",
      "url": "js/deviceInfo.js"
    },
    {
      "hash": "sha256-R7RR2N8XU99nR2csE1PH2wbaC38ezn/im70329h2ezQ=",
      "url": "js/offlineDb.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-rOccmviT/tDD6aAt+idZL+UijJcRktR/hzeKu3LyrUU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-GBPSZCbJ7jt2B3KMT4Ph0ZnbKu7gOENVqpHwbLhpNRM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-2q++/gYCH5kOs4pOTTpAeLQHdBLmKYjCCYoeki4evDE=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-010DfBnfOSjz850qIuePbwz2a5pm55afz9WhRhlQPPs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-Oj8RV2G2qnTUNQMXeBJFblacJlOLSdG1Z5uvQ0Uzb78=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-YHPUhiKUe5tlDx4ZaE3qfRzju/1Prp+ibYzEFTB+kWE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-D+EnRvRuOB65sDHl4GTkpvw8eRvaigODewoN7KR6uis=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-NuJSj11Ox+TMZmKhYei6WngN4OQZrTrqvp/uMBf7Z8E=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-3yMPdt4/YOJyxf0xoGcnghWwYXUwiu5i4yn2fqIK40U=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-cgYRZz9qYmn0XsaiFXMhF487kkqIMR8Vqm7vl1uvaMY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
